# Inside of __init__.py
from simpleimage.Image.py import Image
from simpleimage.Pixel.py import Pixel